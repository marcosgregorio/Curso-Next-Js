export default function handler(req, res) {
    res.status(200).json([100, 200, 300, 400])
}